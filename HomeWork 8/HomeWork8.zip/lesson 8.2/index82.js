const firstEl = document.getElementById("he");
const SecondEl = document.getElementsByClassName("hello");
const ThirdEl = document.querySelector("div");
console.log(firstEl);
console.log(SecondEl[0]);
console.log(ThirdEl);
firstEl.innerText = "Im here";
